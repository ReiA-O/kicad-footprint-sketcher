import math, random, json
from dataclasses import replace
from footprint_sketcher.model import Pad
from footprint_sketcher.graphics import Graphic, graphic_from_points, graphic_outline, world_vertices
from footprint_sketcher.constraints import Constraint, solve_constraints
from footprint_sketcher.editing import mirrored_copies, line_symmetric_copies, point_symmetric_copies
from footprint_sketcher.compound import merge_pads, fillet_pad, world_outline, world_paste_shapes
from shapely import Polygon, LineString
random.seed(20391)
# Exercise reflected polygon/arc geometry against an independently calculated reflection.
checked=0
for k in range(300):
    a=(random.uniform(-8,8),random.uniform(-8,8)); b=(a[0]+random.uniform(.1,8),a[1]+random.uniform(.1,8))
    shape=graphic_from_points('G','polygon',[(0,0),(2,0),(1.5,1),(0,2)])
    shape=replace(shape,x=random.uniform(-5,5),y=random.uniform(-5,5),angle=random.uniform(-360,360))
    reflected=line_symmetric_copies([shape],[],a,b)[0]
    vx,vy=b[0]-a[0],b[1]-a[1]
    def independent(p):
        t=((p[0]-a[0])*vx+(p[1]-a[1])*vy)/(vx*vx+vy*vy)
        q=(a[0]+t*vx,a[1]+t*vy)
        return (2*q[0]-p[0],2*q[1]-p[1])
    err=max(math.dist(independent(old),new) for old,new in zip(world_vertices(shape),world_vertices(reflected)))
    assert err<1e-12,err
    checked+=1
# Solve generated exactly feasible constraints for random center layouts; drivers pin first object.
for k in range(300):
    x,y=random.uniform(-100,100),random.uniform(-100,100)
    dx,dy=random.uniform(-20,20),random.uniform(-20,20)
    pads=[Pad('1',0,0,1,1),Pad('2',0,0,1,1),Pad('3',0,0,1,1)]
    target=[(x,y),(x+dx,y+dy),(x-dx,y-dy)]
    cs=[Constraint('point','symmetric',(1,2),point=(x,y)),Constraint('d1','distance',(0,1),value=math.hypot(dx,dy)),Constraint('d2','distance',(0,2),value=math.hypot(dx,dy))]
    
    try: r=solve_constraints(pads,cs,{0:{'x':x,'y':y}})
    except ValueError as e:
        print('FAILED',k,x,y,dx,dy,str(e));break
    assert max(math.dist((r.pads[i].x,r.pads[i].y),(x,y)) for i in (1,2)) <= math.hypot(dx,dy)+1e-9
    assert abs(r.pads[0].x-x)<=1e-9 and abs(r.pads[0].y-y)<=1e-9
    assert abs(r.pads[1].x+r.pads[2].x-2*x)<=1e-9
    assert abs(r.pads[1].y+r.pads[2].y-2*y)<=1e-9
    for i in (1,2):
        assert abs(math.dist((r.pads[i].x,r.pads[i].y),(x,y))-math.hypot(dx,dy))<=1e-9
    checked+=1
assert checked==600, checked
c=Graphic('C',0,0,2,2,graphic_kind='circle')
r=solve_constraints([c],[Constraint('x','x',(0,),value=0),Constraint('y','y',(0,),value=0),Constraint('r','radius',(0,),value=1)])
print(json.dumps({'independent_property_cases_passed':checked,'case_breakdown':{'graphic_reflections':300,'symmetric_distance_drivers':300},'fixed_circle_without_angle':{'state':r.state,'dof':r.dof,'rank':r.rank}},indent=2))
