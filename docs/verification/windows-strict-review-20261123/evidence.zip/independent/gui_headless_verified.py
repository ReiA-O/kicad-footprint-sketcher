from dataclasses import replace
from types import SimpleNamespace
from shapely import Polygon
from footprint_sketcher.model import Pad,Sketch,Calibration
from footprint_sketcher.compound import merge_pads
from footprint_sketcher.constraints import Constraint
from footprint_sketcher.editing import Snapshot
from footprint_sketcher.layers import expanded_layers,locked_content,layers_locked,visible_layers
# Extract the unchanged method bodies for headless checks: this host has no Tk.
import ast, math
from pathlib import Path
from footprint_sketcher.compound import CustomPad,world_paste_shapes
from footprint_sketcher.graphics import Graphic,graphic_outline
from footprint_sketcher.constraints import solve_constraints

def extract(path, classname, name):
    parsed=ast.parse(Path(path).read_text())
    nodes=next(n for n in parsed.body if isinstance(n,ast.ClassDef) and n.name==classname).body if classname else parsed.body
    method=next(n for n in nodes if isinstance(n,ast.FunctionDef) and n.name==name)
    method.decorator_list=[]
    module=ast.Module(body=[ast.ImportFrom(module='__future__',names=[ast.alias(name='annotations')],level=0),method],type_ignores=[])
    exec(compile(ast.fix_missing_locations(module),str(path),'exec'),globals())
    return globals()[name]
EditorTools=SimpleNamespace(constrain=extract('footprint_sketcher/workspace.py','EditorTools','constrain'))
SketcherApp=SimpleNamespace(_radius_changes=extract('footprint_sketcher/gui.py','SketcherApp','_radius_changes'))
pad_outline=extract('footprint_sketcher/canvas.py',None,'pad_outline')
SketchCanvas=SimpleNamespace(_draw_pad=extract('footprint_sketcher/canvas.py','SketchCanvas','_draw_pad'))
BLUE='blue';TEAL='teal';WORKSPACE='white';INK='black'

assert expanded_layers(('*.Cu','*.Mask')) == {'F.Cu','B.Cu','F.Mask','B.Mask'}
assert layers_locked(('*.Cu',),{'F.Cu'})
assert visible_layers(('*.Cu','*.Mask'),{'F.Cu','B.Cu','F.Mask'}) == {'B.Mask'}
p=Pad('1',0,0,1,1,layers=('*.Cu','*.Mask'),pad_type='thru_hole',drill_width=.5,drill_height=.5)
assert locked_content([p,p],{'F.Cu'}) != locked_content([p],{'F.Cu'})

s=Sketch();s.pads=[Pad('F',0,0,1,1,layers=('F.Cu',)),Pad('B',2,0,1,1,layers=('B.Cu',))]
s.constraints=[Constraint('row','horizontal',(0,1))]
before=Snapshot.capture(s)
s.pads[0]=replace(s.pads[0],y=1)
app=SimpleNamespace(sketch=s,canvas=SimpleNamespace(locked_layers={'B.Cu'}))
try:
    EditorTools.constrain(SimpleNamespace(app=app),before)
    raise AssertionError('solver moved locked content')
except ValueError as e:
    assert '拘束の追従' in str(e)

for shape in [Pad('P',0,0,2,2,pad_shape='rect'),Pad('P',0,0,2,2,pad_shape='roundrect',radius=.2)]:
    rounded=replace(shape,**SketcherApp._radius_changes(shape,.3))
    assert (rounded.pad_shape,rounded.radius)==('roundrect',.3)
    squared=replace(rounded,**SketcherApp._radius_changes(rounded,0))
    assert (squared.pad_shape,squared.radius)==('rect',0)

class FakeCanvas:
    hidden_layers={'F.Cu','F.Paste'}
    def __init__(self): self.polygons=[]
    def _pad_vertices(self,pad,sketch,points): return list(points)
    def _clipped(self,points): return points
    def create_polygon(self,points,**kw): self.polygons.append((points,kw))
    def create_line(self,*args,**kw): pass
    def image_to_canvas(self,p): return (-100,-100)
    def winfo_width(self): return 1
    def winfo_height(self): return 1
s=Sketch();s.calibration=Calibration((0,0),(1,0),1);s.origin=(0,0)
base=merge_pads([Pad('1',-1.5,0,2,2),Pad('2',1.5,0,2,2),Pad('3',0,0,2,.4)],'S')
split=replace(base,mask_margin=-.3)
canvas=FakeCanvas();SketchCanvas._draw_pad(canvas,split,s,index=0)
assert len(canvas.polygons)==2
assert abs(sum(Polygon(x).area for x,_ in canvas.polygons)-Polygon(split.outline).buffer(-.3).area)<1e-12
sources=[Pad('L',-2.5,0,1,6),Pad('T',0,-2.5,6,1),Pad('B',0,2.5,6,1),Pad('RT',2.5,-1.75,1,1.5),Pad('RB',2.5,1.75,1,1.5)]
holed=replace(merge_pads(sources,'C'),mask_margin=1.1)
canvas=FakeCanvas();SketchCanvas._draw_pad(canvas,holed,s,index=0)
expected=Polygon(holed.outline).buffer(1.1)
actual=sum(Polygon(x).area for x,_ in canvas.polygons)
from shapely import union_all
import json
displayed=union_all([Polygon(points) for points,_ in canvas.polygons])
assert len(expected.interiors)==1
assert expected.symmetric_difference(displayed).area<1e-10
print(json.dumps({'passed_check_groups':['wildcard_layers','locked_duplicate','solver_locked_propagation','radius_rect','radius_roundrect','mask_split','mask_hole'],'mask_hole':{'expected_area_mm2':expected.area,'drawn_polygon_area_sum_mm2':actual,'union_area_mm2':displayed.area,'symmetric_difference_area_mm2':expected.symmetric_difference(displayed).area,'expected_hole_count':len(expected.interiors),'drawn_hole_count':len(displayed.interiors)}},indent=2))
