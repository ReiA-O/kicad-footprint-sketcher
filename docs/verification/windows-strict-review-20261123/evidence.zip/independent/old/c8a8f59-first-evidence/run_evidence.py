"""Capture actual execution output and the exact application source tested."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument("--repo", default="/home/reia/NotoWork/projects/kicad-footprint-sketcher")
parser.add_argument("--python", default="/home/reia/NotoWork/venvs/kicad-compound/bin/python")
args = parser.parse_args()
repo, output = Path(args.repo).resolve(), Path(__file__).resolve().parent

def git(*args):
    return subprocess.check_output(["git", *args], cwd=repo, text=True).strip()

def sources():
    return {str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in sorted((repo / "footprint_sketcher").glob("*.py"))}

before = sources()
metadata = dict(started_utc=datetime.now(timezone.utc).isoformat(), repository=str(repo),
                head=git("rev-parse", "HEAD"), tree=git("rev-parse", "HEAD^{tree}"),
                initial_status_porcelain=git("status", "--porcelain"),
                host_platform=platform.platform(), python=args.python, sources_sha256=before)
snapshot = output / "source-snapshot" / "footprint_sketcher"
snapshot.mkdir(parents=True, exist_ok=True)
for relative in before:
    shutil.copyfile(repo / relative, snapshot / Path(relative).name)
(output / "source.patch").write_bytes(subprocess.check_output(
    ["git", "diff", "--binary", "HEAD", "--", "footprint_sketcher"], cwd=repo))
env = dict(os.environ, PYTHONPATH=str(repo))
metadata["runtime"] = json.loads(subprocess.check_output(
    [args.python, "-c", "import sys,json,importlib.metadata as m; print(json.dumps({'python':sys.version,'packages':{n:m.version(n) for n in ['numpy','Shapely','Pillow']}}))"],
    text=True, cwd=repo, env=env))
metadata["runs"] = {}
for name in ("independent_random_600_original", "independent_random_600_verified",
             "gui_headless_original", "gui_headless_verified"):
    script = output / (name + ".py")
    result = subprocess.run([args.python, str(script)], cwd=repo, env=env,
                            text=True, capture_output=True)
    (output / (name + ".stdout.log")).write_text(result.stdout)
    (output / (name + ".stderr.log")).write_text(result.stderr)
    run = dict(exit_code=result.returncode, script_sha256=hashlib.sha256(script.read_bytes()).hexdigest())
    try:
        parsed = json.loads(result.stdout)
        (output / (name + ".result.json")).write_text(json.dumps(parsed, ensure_ascii=False, indent=2) + "\n")
        run["result_json"] = name + ".result.json"
    except json.JSONDecodeError:
        pass
    metadata["runs"][name] = run
metadata.update(finished_utc=datetime.now(timezone.utc).isoformat(), final_head=git("rev-parse", "HEAD"),
                final_status_porcelain=git("status", "--porcelain"), sources_stable=before == sources())
(output / "execution-metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"head":metadata["head"], "sources_stable":metadata["sources_stable"],
                  "exit_codes":{name:run["exit_code"] for name,run in metadata["runs"].items()}}, indent=2))
raise SystemExit(0 if metadata["sources_stable"] and all(run["exit_code"] == 0 for run in metadata["runs"].values()) else 1)
