# 独立レビューの再実行証跡

2026-11-23 11:03:06 JSTにLinux / Python 3.14.4で最終版を再実行しました。対象はコミット `28d832149979f0431c42054474bb4b01aa5c1946`、tree `c3100f357a49e1938c128556c343dbd6b3edaa3f` です。開始・終了とも作業ツリーはcleanで、実行中のアプリソース変更はありません。

先行レビュー時の実行は旧HEAD `fb0bccf6cf61017558a212b49737f1b7d51e3687` に未コミットの修正を重ねた状態でした。その時点のスクリプトを `*_original.py` として保持しています。最初のclean HEAD `c8a8f59a7e7d826899b41342f27ffd197f47ff80` での再実行証跡は、README・JSON/log・ソースsnapshotごと `old/c8a8f59-first-evidence/` に保存しました。本ディレクトリ直下のJSON/logとsnapshotは、上記の最終HEADで今回実際に再実行した内容です。過去のログとして再構成していません。

## 内容と件数

| 対象 | 確認内容 | 今回の結果 |
| --- | --- | --- |
| `independent_random_600_original.py` | seed 20391。多角形の任意軸反射300ケース、同位置からの対称・距離拘束と駆動値300ケース。元のassertを保持。 | 600ケース、終了コード0 |
| `independent_random_600_verified.py` | 同じ600入力に、件数600のassert、駆動位置・点対称・両距離の独立残差確認を追加。 | 600ケース、終了コード0 |
| `gui_headless_original.py` | wildcard層、重複ロック、solver経由のロック保護、R変更、Maskの分割・穴について、実メソッド本体をAST抽出して呼出し。 | 終了コード0 |
| `gui_headless_verified.py` | 上記7確認群に加え、穴のあるMaskの描画polygon群と真のbufferの対称差をassert。 | 7群通過、対称差面積0 mm²、穴数1で一致 |

`verified`版は証跡保存時にassertを補強した版です。同じ600入力の再確認を1200件の独立ケースとは数えません。元の拘束ケースは戻り値と距離上限のみをassertしていたため、補強版では指定値との一致も独立に検証しました。

円のX/Y/R固定後に残る数値angle自由度1の観測もJSONへ記録しています。これは今回明記された数値属性の自由度という仕様に対応します。ランダム600ケースには含めません。

GUI headlessはR変更ヘルパーのrect/roundrect各1例と、Canvasへ渡すpolygon群の幾何を確認します。Tk描画、文字・画面配置、実イベント、通常ダイアログ、Windows、KiCadの実行確認には代えません。

## 再実行

```bash
<WORKSPACE>/venvs/kicad-compound/bin/python \
  <WORKSPACE>/kicad-strict-review-20261123/independent/run_evidence.py \
  --repo <REPO> \
  --python <WORKSPACE>/venvs/kicad-compound/bin/python
```

このコマンドは本ディレクトリの結果ファイルとsnapshotを更新します。元の証跡を残す場合はディレクトリを複製してから実行してください。アプリのリポジトリには書き込みません。

`execution-metadata.json` に時刻、HEAD/tree、clean状態、実際の依存バージョン、スクリプト・アプリソースのSHA-256、各終了コードを保存しています。`source-snapshot/footprint_sketcher/` は今回実行したアプリのPythonソース全14ファイルです。`source.patch` は今回の未コミット差分で、cleanのため空です。標準出力・標準エラーを各 `*.stdout.log` / `*.stderr.log` にそのまま保存し、JSON出力には `*.result.json` も付けています。
