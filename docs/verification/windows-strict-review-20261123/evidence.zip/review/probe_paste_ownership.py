from pathlib import Path
import json,pcbnew
p=Path(r'D:\CodexWork\tasks\kicad-stage1-validation-20261123')
f=pcbnew.FootprintLoad(str(p),'Strict_Paste_Ownership')
print(json.dumps({'kicad':pcbnew.Version(),'pads':[{'number':v.GetNumber(),'x_nm':v.GetPosition().x,'y_nm':v.GetPosition().y,'layers':v.GetLayerSet().FmtBin()} for v in f.Pads()]},ensure_ascii=False))
